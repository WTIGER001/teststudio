import { test, expect } from '@playwright/test'
test('shows a greeting', {tag:'@BROWSER-UPLOAD-001'}, async ({page})=>{await page.setContent('<h1>New greeting</h1>');await expect(page.getByRole('heading',{name:'New greeting'})).toBeVisible()})
