import { defineConfig } from '@playwright/test'
export default defineConfig({testDir:'checks',projects:[{name:'chromium',use:{browserName:'chromium'}}]})
