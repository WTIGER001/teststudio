module suite.local/totals

go 1.24
