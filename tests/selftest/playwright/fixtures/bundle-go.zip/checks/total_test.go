package checks
import "testing"
func TestTotal(t *testing.T) { if 10+12!=22 { t.Fatal("total") } }
